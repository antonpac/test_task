package test.com.test_project;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.text.SimpleDateFormat;

/**
 * Created by anton on 14.10.2016.
 */
public class ChooseActivity extends AppCompatActivity {


    private Button btnSearch;
    private EditText txtSearch;
    private ListView mListView;
    private String str;
    private ArrayAdapter<String> mAdapter;
    private int ItemPositon;
    private String currentCountry;
    private String currentCity;
    private Boolean flag_city;
    private Boolean flag_station;
    private Boolean flag_from = false;
    private Intent res_intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);

        res_intent = new Intent();
        //адаптер для ListView
        mAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1);

        btnSearch = (Button) findViewById(R.id.button_search);
        txtSearch = (EditText) findViewById(R.id.search);
        mListView = (ListView) findViewById(R.id.list);

        flag_city = false;
        flag_station = false;

        Intent intent = getIntent();
        String via = intent.getStringExtra("via");
        if(via.equals("FROM"))//назначаем флаги для выбора станций из списка либо отправления, либо назначения
        {
            flag_from = true;
        }
        else
        {
            flag_from = false;
        }

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // do something when the corky2 is clicked
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
            }
        });


        /* создаем несколько потоков для работы с данными
        для извлечения названий стран, городов и станций из json-файла
        
         */

        Runnable runnable = new Runnable() {
            public void run() {
                str = getStr();

                JSONObject dataJSON = null;
                try
                {

                    dataJSON = new JSONObject(str);
                    JSONArray citiesFrom = null;
                    if(flag_from) {
                        citiesFrom = dataJSON.getJSONArray("citiesFrom");
                    }
                    else
                    {
                        citiesFrom = dataJSON.getJSONArray("citiesTo");
                    }

                    int i=0;
                    while(i<citiesFrom.length()) {
                        Message msg = handler.obtainMessage();
                        Bundle bundle = new Bundle();
                        msg.setData(bundle);
                        handler.sendMessage(msg);
                        JSONObject firstCity = citiesFrom.getJSONObject(i);
                        bundle.putString("Key", firstCity.getString("countryTitle").toString());
                        i++;

                        while(i<citiesFrom.length()&&
                                (firstCity.getString("countryTitle").toString().equals(
                                citiesFrom.getJSONObject(i).getString("countryTitle").toString())))
                        {
                            i++;
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }



            }
        };

        Thread thread = new Thread(runnable);
        thread.start();

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

                ItemPositon = position;
                if(!flag_station) {
                    if (!flag_city) {
                        flag_city = true;
                        currentCountry = mAdapter.getItem(ItemPositon);
                        res_intent.putExtra("Country", currentCountry);
                        mAdapter.clear();
                        Runnable runnable = new Runnable() {
                            public void run() {
                                JSONObject dataJSON = null;
                                try {
                                    dataJSON = new JSONObject(str);

                                    JSONArray citiesFrom = null;
                                    if (flag_from) {
                                        citiesFrom = dataJSON.getJSONArray("citiesFrom");
                                    } else {
                                        citiesFrom = dataJSON.getJSONArray("citiesTo");
                                    }

                                    boolean flag_break=false;

                                    int i = 0;

                                    while (i < citiesFrom.length()) {
                                        Message msg = handler.obtainMessage();
                                        Bundle bundle = new Bundle();
                                        msg.setData(bundle);
                                        handler.sendMessage(msg);
                                        JSONObject firstCity = citiesFrom.getJSONObject(i);

                                        if (firstCity.getString("countryTitle").toString().equals(currentCountry)) {
                                            bundle.putString("City", firstCity.getString("cityTitle").toString());
                                            flag_break = true;
                                            str+=firstCity.toString();
                                        }
                                        else
                                        {
                                            if(flag_break)
                                            {

                                                break;
                                            }
                                        }
                                        i++;
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                        };

                        Thread thread = new Thread(runnable);
                        thread.start();
                    } else {
                        flag_station = true;
                        currentCity = mAdapter.getItem(ItemPositon);
                        res_intent.putExtra("City", currentCountry);
                        mAdapter.clear();
                        Runnable runnable = new Runnable() {
                            public void run() {
                                JSONObject dataJSON = null;
                                try {
                                    dataJSON = new JSONObject(str);

                                    JSONArray citiesFrom = null;
                                    if (flag_from) {
                                        citiesFrom = dataJSON.getJSONArray("citiesFrom");
                                    } else {
                                        citiesFrom = dataJSON.getJSONArray("citiesTo");
                                    }


                                    int i=0;
                                    while (i < citiesFrom.length()) {
                                        Message msg = handler.obtainMessage();
                                        Bundle bundle = new Bundle();
                                        msg.setData(bundle);
                                        handler.sendMessage(msg);
                                        JSONObject firstCity = citiesFrom.getJSONObject(i);
                                        if (firstCity.getString("cityTitle").toString().equals(currentCity)) {
                                            int j = 0;
                                            while (j < firstCity.getJSONArray("stations").length()) {
                                                bundle.putString("Stations",
                                                        firstCity.getJSONArray("stations").getJSONObject(j).getString("stationTitle"));
                                                j++;
                                            }
                                        }
                                        break;
                                    }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        };
                        Thread thread = new Thread(runnable);
                        thread.start();
                    }
                }
                else
                {
                    currentCountry = mAdapter.getItem(ItemPositon);
                    res_intent.putExtra("Station", currentCountry);
                    setResult(RESULT_OK,res_intent);
                    finish();
                }
            }
        });
    }

    Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            if(bundle.getString("Key")!=null) {
                String date = bundle.getString("Key");
                mAdapter.add(date);
                mListView.setAdapter(mAdapter);
            }
            if(bundle.getString("City")!=null) {
                String date = bundle.getString("City");
                mAdapter.add(date);
                mListView.setAdapter(mAdapter);
            }
            if(bundle.getString("Stations")!=null) {
                String date = bundle.getString("Stations");
                mAdapter.add(date);
                mListView.setAdapter(mAdapter);
            }
        }
    };

    public String getStr()
    {
        InputStream is = getResources().openRawResource(R.raw.allstations);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024*1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String jsonString = writer.toString();
        return jsonString;
    }
}