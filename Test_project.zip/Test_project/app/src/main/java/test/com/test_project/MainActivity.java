package test.com.test_project;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    /*
    Тестовое задание выполненно лишь частично
    нет поиска по городам
    данные загружаются очень медленно
    не было опыта работы с json объектами
     */


    public Button btnSh;//кнопка расписания
    public Button btnInfo;//кнопка информации

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSh = (Button) findViewById(R.id.shedule);
        btnInfo = (Button) findViewById(R.id.info);

        btnSh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), Shedule.class);//переходим на активити Shedule
                startActivity(intent);
            }
        });

        btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), About.class);
                startActivity(intent);
            }
        });
    }
}
