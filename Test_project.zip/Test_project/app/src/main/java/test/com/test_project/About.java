package test.com.test_project;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by anton on 12.10.2016.
 */
public class About extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
    }
}
