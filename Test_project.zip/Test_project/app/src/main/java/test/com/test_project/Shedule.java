package test.com.test_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Created by anton on 12.10.2016.
 */
public class Shedule extends AppCompatActivity {

    private Button mDepart;//кнопка для выбора станции отправления
    private Button mArrival;//кнопка для выбора станции назначения
    private LinearLayout llParams;
    private LinearLayout flContainer;
    private String direction;


    public static final int REQUEST_CODE_DEPART = 0;
    public static final int REQUEST_CODE_ARRIVAL = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shedule);

        mDepart = (Button) findViewById(R.id.depart);
        mArrival = (Button) findViewById(R.id.arrival);


        mDepart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ChooseActivity.class);
                intent.putExtra("via", "FROM");
                startActivityForResult(intent, REQUEST_CODE_DEPART);//запускаем активити для выбора станции отправления
            }
        });

        mArrival.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ChooseActivity.class);
                intent.putExtra("via", "TO");
                startActivityForResult(intent, REQUEST_CODE_ARRIVAL);//запускаем активити для выбора станции отправления
            }
        });
    }


    //получаем информацию с запушенного активити
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // запишем в лог значения requestCode и resultCode
        Log.d("myLogs", "requestCode = " + requestCode + ", resultCode = " + resultCode);
        // если пришло ОК
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case REQUEST_CODE_DEPART:
                    direction+=(data.getStringExtra("County"));
                    direction+=(" ");
                    direction+=(data.getStringExtra("City"));
                    direction+=(" ");
                    direction+=(data.getStringExtra("Station"));
                    mDepart.setText(direction);
                    direction = "";
                    break;
                case REQUEST_CODE_ARRIVAL:
                    direction+=(data.getStringExtra("County"));
                    direction+=(" ");
                    direction+=(data.getStringExtra("City"));
                    direction+=(" ");
                    direction+=(data.getStringExtra("Station"));
                    mDepart.setText(direction);
                    direction = "";
                    break;
            }
            // если вернулось не ОК
        } else {
            Toast.makeText(this, "Wrong result", Toast.LENGTH_SHORT).show();
        }
    }



}
